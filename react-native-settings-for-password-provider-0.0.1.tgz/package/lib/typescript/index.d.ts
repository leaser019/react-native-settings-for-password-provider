import type { ESettings } from './types';
/**
 * @description function to open settings for platform android and ios
 * @param {value} value enum ESettings
 */
export declare function openSettings(value: ESettings): void;
/**
 * @description working only Platform Android
 */
export declare function locationSettings(): void;
/**
 * @description working only Platfrom IOS
 */
export declare function checkAllowLocationServices(): Promise<boolean>;
export { ESettings } from './types';
//# sourceMappingURL=index.d.ts.map